package com.example.chalkboardnew.Notifications;

public class MyResponse {
    public int success;
}
