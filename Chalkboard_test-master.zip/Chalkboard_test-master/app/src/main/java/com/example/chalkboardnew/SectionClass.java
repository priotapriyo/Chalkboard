package com.example.chalkboardnew;

public class SectionClass {
    String section;

    public SectionClass() {
    }

    public SectionClass(String section) {
        this.section = section;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
