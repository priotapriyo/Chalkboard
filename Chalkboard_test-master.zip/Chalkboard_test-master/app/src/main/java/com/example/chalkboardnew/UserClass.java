package com.example.chalkboardnew;

public class UserClass {
    public  String choice;

    public UserClass()
    {

    }
    public UserClass(String choice) {
        this.choice = choice;

    }


    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }
}
