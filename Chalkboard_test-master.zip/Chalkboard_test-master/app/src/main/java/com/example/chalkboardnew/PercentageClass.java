package com.example.chalkboardnew;

public class PercentageClass {
    double percentage;

    public PercentageClass() {
    }

    public PercentageClass(double percentage) {
        this.percentage = percentage;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}
