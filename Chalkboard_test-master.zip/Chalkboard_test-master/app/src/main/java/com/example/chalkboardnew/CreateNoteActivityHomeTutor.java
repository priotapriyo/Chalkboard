package com.example.chalkboardnew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreateNoteActivityHomeTutor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_note_home_tutor);
    }
}