package com.example.chalkboardnew;

public class dataModel {
    Boolean checked;

    public dataModel() {
    }

    public dataModel(Boolean checked) {
        this.checked = checked;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }
}
