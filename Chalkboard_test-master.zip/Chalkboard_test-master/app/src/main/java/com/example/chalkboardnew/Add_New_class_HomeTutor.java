package com.example.chalkboardnew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Add_New_class_HomeTutor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add__new_class__home_tutor);
    }
}