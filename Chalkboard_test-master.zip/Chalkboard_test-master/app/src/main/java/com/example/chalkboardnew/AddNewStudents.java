package com.example.chalkboardnew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddNewStudents extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_students);
    }
}
